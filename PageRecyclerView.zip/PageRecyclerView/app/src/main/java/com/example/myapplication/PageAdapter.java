package com.example.myapplication;

import android.content.Context;
import android.content.res.Configuration;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;

import org.jetbrains.annotations.NotNull;

import java.util.List;

public class PageAdapter extends RecyclerView.Adapter<PageAdapter.PageViewHolder> {

    private Context mContext;
    private List<String> mData;

    public PageAdapter(Context mContext, List<String> mData) {
        this.mContext = mContext;
        this.mData = mData;
    }

    @NonNull
    @NotNull
    @Override
    public PageViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent, int viewType) {
        return new PageViewHolder(LayoutInflater.from(mContext).inflate(R.layout.item_page,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull @NotNull PageViewHolder holder, int position) {

        int screenWidth = ScreenUtils.getScreenWidth(mContext);
        int padding = 0;
        int divide = 0;
        int itemWidth = 0;
        int itemHeight = 0;
        Configuration mConfiguration = mContext.getResources().getConfiguration(); //获取设置的配置信息
        int ori = mConfiguration.orientation; //获取屏幕方向
        if (ori == mConfiguration.ORIENTATION_LANDSCAPE) {
            padding = DensityUtils.dip2px(mContext,15);
            divide = DensityUtils.dip2px(mContext, 5);
        }else {
            padding = DensityUtils.dip2px(mContext, 11);
            divide = DensityUtils.dip2px(mContext, 4);
        }

        if(ori == mConfiguration.ORIENTATION_LANDSCAPE){
            itemWidth = (int) ((screenWidth - padding * 2 - divide * 3f *2)/3);
        }else {
            itemWidth = screenWidth - padding * 2 -divide *2;
        }
        itemHeight = (int) (itemWidth * 9.0f/16);

        RelativeLayout.LayoutParams params = (RelativeLayout.LayoutParams) holder.rlItem.getLayoutParams();
        params.width = itemWidth;
        params.height = itemHeight;
        params.leftMargin = divide;
        params.rightMargin = divide;
        holder.rlItem.setLayoutParams(params);

        Glide.with(mContext).load(mData.get(position)).into(holder.icon);
        holder.name.setText(String.valueOf(position));

    }

    @Override
    public int getItemCount() {
        return mData.size();
    }

    class PageViewHolder extends RecyclerView.ViewHolder{

        RelativeLayout rlItem;
        ImageView icon;
        TextView name;

        public PageViewHolder(@NonNull @NotNull View itemView) {
            super(itemView);
            rlItem = itemView.findViewById(R.id.rl_item);
            icon = itemView.findViewById(R.id.iv_icon);
            name = itemView.findViewById(R.id.tv_name);
        }
    }
}
