package com.example.myapplication;

import android.content.res.Configuration;
import android.graphics.Color;
import android.os.Bundle;
import android.util.Log;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.LinearSnapHelper;
import androidx.recyclerview.widget.PagerSnapHelper;
import androidx.recyclerview.widget.RecyclerView;

import com.yqritc.recyclerviewflexibledivider.VerticalDividerItemDecoration;

import org.jetbrains.annotations.NotNull;

import java.util.ArrayList;
import java.util.List;

public class PageRecyclerActivity extends AppCompatActivity {

    private static String TAG = "PageRecyclerActivity";

    private RecyclerView recyclerView;
    private PageAdapter pageAdapter;
    private List<String> mData = new ArrayList<>();


    @Override
    protected void onCreate(@Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_page_recycler);

        mData.add("https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=1396521707,1973816781&fm=26&gp=0.jpg");
        mData.add("https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2032109681,1516567761&fm=26&gp=0.jpg");
        mData.add("https://ss1.bdstatic.com/70cFvXSh_Q1YnxGkpoWK1HF6hhy/it/u=2080110811,891738648&fm=26&gp=0.jpg");
        mData.add("https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=1344528693,2427862478&fm=26&gp=0.jpg");
        mData.add("https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=2189812868,3743840074&fm=26&gp=0.jpg");
        mData.add("https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=2431408801,2858187201&fm=26&gp=0.jpg");
        mData.add("https://ss2.bdstatic.com/70cFvnSh_Q1YnxGkpoWK1HF6hhy/it/u=3657662623,433078903&fm=26&gp=0.jpg");
        mData.add("https://ss0.bdstatic.com/70cFuHSh_Q1YnxGkpoWK1HF6hhy/it/u=3568306909,3947147617&fm=26&gp=0.jpg");

        recyclerView = findViewById(R.id.recyclerView);

        Configuration mConfiguration = getResources().getConfiguration(); //获取设置的配置信息
        int ori = mConfiguration.orientation; //获取屏幕方向
        int padding;
        if(ori == Configuration.ORIENTATION_LANDSCAPE){
            padding = DensityUtils.dip2px(getApplicationContext(), 15);
        }else{
            padding = DensityUtils.dip2px(getApplicationContext(), 11);
        }

        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(PageRecyclerActivity.this);
        linearLayoutManager.setOrientation(RecyclerView.HORIZONTAL);
        recyclerView.setLayoutManager(linearLayoutManager);
        new LinearSnapHelper().attachToRecyclerView(recyclerView);
        recyclerView.setPadding(padding,0,padding,0);
        pageAdapter = new PageAdapter(getApplicationContext(),mData);
        recyclerView.setAdapter(pageAdapter);
    }

    @Override
    public void onConfigurationChanged(@NonNull @NotNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);

        Log.e(TAG, "onConfigurationChanged");

        int padding;
        if(newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE){
            padding = DensityUtils.dip2px(getApplicationContext(), 10);
        }else{
            padding = DensityUtils.dip2px(getApplicationContext(), 7);
        }
        recyclerView.setPadding(padding,0,padding,0);
        pageAdapter.notifyDataSetChanged();
    }
}
